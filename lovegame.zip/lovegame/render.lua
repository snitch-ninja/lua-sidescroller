local render = {}

function render.draw()
     tempf = char.dir.maxx/math.abs(char.dir.maxx)
    if (tempf == -1) or (tempf == 1) then
        char.facing = tempf
    end
    
    local movPos = math.mod(char.x*screen.width, screen.width)

    local draw = love.graphics.draw

--[[ DRAW BACKGROUND ]]
    draw(background, movPos,0,0,screen.width/299,screen.height/172/2)
    draw(background, movPos-screen.width,0,0,screen.width/299,screen.height/172/2)
    draw(background, movPos+screen.width,0,0,screen.width/299,screen.height/172/2)
--[[ END BACKGROUND ]]

--[[ DRAW FOREGROUND ]]
    
    for i = 1, 10 do
        draw(dirt, movPos+(screen.width/10)*i, screen.height/2+(screen.height*(23/48)/4), 0, screen.width/48/10,screen.height/2/48/2)
        draw(dirt, movPos+screen.width+(screen.width/10)*i,screen.height/2+(screen.height*(23/48)/4), 0, screen.width/48/10,screen.height/2/48/2)
        draw(dirt, movPos-screen.width+(screen.width/10)*i,screen.height/2+(screen.height*(23/48)/4), 0, screen.width/48/10,screen.height/2/48/2)
    
        draw(tallgrass, movPos+(screen.width/10)*i, screen.height/2-(screen.height*(24/48)/4/2), 0, screen.width/48/10,screen.height/2/48/2/2)
        draw(tallgrass, movPos+screen.width+(screen.width/10)*i,screen.height/2-(screen.height*(24/48)/4/2), 0, screen.width/48/10,screen.height/2/48/2/2)
        draw(tallgrass, movPos-screen.width+(screen.width/10)*i,screen.height/2-(screen.height*(24/48)/4/2), 0, screen.width/48/10,screen.height/2/48/2/2)
        
        draw(grass, movPos+(screen.width/10)*i, screen.height/2, 0, screen.width/48/10,screen.height/2/48/2)
        draw(grass, movPos+screen.width+(screen.width/10)*i,screen.height/2, 0, screen.width/48/10,screen.height/2/48/2)
        draw(grass, movPos-screen.width+(screen.width/10)*i,screen.height/2, 0, screen.width/48/10,screen.height/2/48/2)
    
    end
    
    
--[[ END FOREGROUND ]]

--[[ DRAW TREES ]]
    for i = 1, #trees do
        draw(tree,(char.x+trees[i].x)*screen.width-trees.size.x/2,0.5*screen.height-trees.size.y, 0, trees.size.x/4992, trees.size.y/4478)
    end
--[[ END TREES ]]

--[[ DRAW STONES ]]
    for i = 1, #stones do
        draw(stone,(char.x+stones[i].x)*screen.width-stones.size.x/2,0.5*screen.height-stones.size.y, 0, stones.size.x/76, stones.size.y/73)
    end
--[[ END STONES ]]

--[[ DRAW CHARACTER ]]
    love.graphics.rectangle("fill", 0.5*screen.width-char.size*0.25,0.5*screen.height-char.size*1.5, char.size*0.5, char.size*1.5)
    if gui.buttons[4].scale < 1 then
        draw(axe0, 32+0.5*screen.width-char.size*0.25-(((64*3))*char.facing),0.5*screen.height-char.size*1.5,0, char.facing*3,3)
    end
--[[ END CHARACTER ]]

--[[ DRAW TEXT ]]
--TODO: ADD "CHAT LOG" TO SHOW ACTIVITY SUCH AS "+1 WOOD"
    love.graphics.setColor(0, 0, 0)
    love.graphics.print("food: "..math.floor(food), 0, 0)
    love.graphics.print("wood: "..math.floor(wood), 0, 100)
    love.graphics.print("stne: "..math.floor(stne), 0, 200)
--[[ END TEXT ]]
end

return render