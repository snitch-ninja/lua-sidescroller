screen = {}
screen.width, screen.height = 
    love.graphics.getDimensions ()

food, wood, stne = 0,0,0

font = love.graphics.newFont("assets/joystix monospace.ttf", 72)
love.graphics.setFont(font)
ar = screen.width/screen.height

tasks = {}

char = {
    x = 0,
    y = 0,
    dir = {
        x = 0,
        y = 0,
        maxx=0
    },
    size = screen.width*0.05,
    facing = 1
}

trees = {
    {
        health = 1,
        x = 0.5
    },
    size = {
        x = screen.height* 0.4*(4992/4478),
        y = screen.height* 0.5*(4478/4992)
    }
}

stones = {
    {
        health = 1,
        x = 0.75
    },
    size = {
        x = screen.height*0.125,
        y = screen.height*0.125
    }
}

background = love.graphics.newImage("assets/sky.png")
dirt = love.graphics.newImage("assets/dirt.png")
grass = love.graphics.newImage("assets/grass.png")
tallgrass = love.graphics.newImage("assets/tallgrass.png")

--TODO: CREATE ANIMATION FOR AXE
--TODO: ON ATTACK BUTTON PRESS, QUEUE ANIMATION START. ANIMATION STARTS IF (QUEUE) AND (ANIMATION ISNT PLAYING)
axe0 = love.graphics.newImage("assets/axe_0.png")

tree = love.graphics.newImage("assets/tree.png")
stone = love.graphics.newImage("assets/boulder.png")

love.graphics.setDefaultFilter("nearest", "nearest", 1)

gui = require "gui"
render = require "render"

function love.draw ()
    love.graphics.setColor(255, 255, 255)
    
    render.draw()
    gui.draw()

end

function love.touchpressed(id,x,y)
    if not id == 0 then
        return nil
    end
    gui.pressed(x,y)
end

function love.update(dt)

    for i = 1, #tasks do
        if tasks[i] then
            if tasks[i].seconds <= 0 then
                tasks[i].task()
                table.remove(tasks, i)
            else
                tasks[i].seconds = tasks[i].seconds - dt
            end
        end
    end

    char.x = char.x + char.dir.x*dt

    if char.dir.maxx and 
           (not (char.dir.x==char.dir.maxx)) then

        --ween to max moving speed in 1/8 seconds
        char.dir.x = char.dir.x + (((char.dir.maxx-char.dir.x)*8)*dt)

        if math.abs(char.dir.maxx-char.dir.x) <=
                ((((char.dir.maxx-char.dir.x)*8)*dt)) then
            char.dir.x = char.dir.maxx
        end
    end

--[[ COLLECT TREES ]]
    for i = 1, #trees do
        if char.swinging and math.abs(((char.x+trees[i].x)*screen.width)-(screen.width/2)) < 64 then
--FINISH FROZEN STATE
char.frozen = true
            delayDo(0.25, function()
wood = wood + 1
char.swinging = false
char.frozen = false
end)
            break
        end
    end
--[[ END TREES ]]

--[[ COLLECT STONES ]]
    for i = 1, #stones do
        if char.swinging and math.abs(((char.x+stones[i].x)*screen.width)-(screen.width/2)) < 64 then
            stne = stne + 1
            delayDo(0.25, function() char.swinging = false end)
            break
        end
    end
--[[ END STONES ]]

end

--TODO: TRACK TOUCH IDS AND ONLY RESET THE APPROPRIATE DATA
function love.touchreleased (id,x,y)
    if not id == 0 then
        return nil
    end
    for i = 1, #gui.buttons do
        gui.buttons[i].scale = 1
    end

    char.swinging = false
    char.dir.maxx=0
end

function inBox (x,y, bX,bY,bW,bH)
    return ((x>bX)          and
               (x<(bX+bW)) and
               (y>bY)            and
               (y<(bY+bH)))
end

function delayDo(seconds_, task_)
    tasks[#tasks+1] = {task = task_, seconds = seconds_}
end