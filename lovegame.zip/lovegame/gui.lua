local buttonSizeX = 0.15
local buttonSizeY = buttonSizeX*ar

local leftArrow = love.graphics.newImage("assets/Sprites/shadedLight/shadedLight24.png")
local rightArrow = love.graphics.newImage("assets/Sprites/shadedLight/shadedLight25.png")
local crafter = love.graphics.newImage("assets/Sprites/shadedLight/shadedLight22.png")
local attacker = love.graphics.newImage("assets/Sprites/shadedLight/shadedLight48.png")

local gui = {}

gui.buttons = {
    { --left dir1
        img=leftArrow,
        x=  buttonSizeX/2,
        y=1-buttonSizeY/2,
        scale=1,
        xp=80,yp=80,
        onPress=function()
            gui.buttons[1].scale = 0.9
            char.dir.maxx = 0.5
        end
    },

    { --right dir2
        img=rightArrow,
        x=1-buttonSizeX/2,
        y=1-buttonSizeY/2,
        scale=1,
        xp=80,yp=80,
        onPress=function()
            gui.buttons[2].scale = 0.9
            char.dir.maxx = -0.5
        end
    },

    { --craft button3
        img=crafter,
        x=  buttonSizeX*1.667,
        y=1-buttonSizeY/3.333,
        scale=1,
        xp=80,yp=80,
        onPress=function()
            gui.buttons[3].scale = 0.9
            --TODO open crafting menu
        end
    },

    { --use/attack button4
        img=attacker,
        x=1-buttonSizeX/3,
        y=1-buttonSizeY*1.333,
        scale=1,
        xp=120,yp=120,
        onPress=function()
            gui.buttons[4].scale = 0.9
            char.swinging = true
        end
    }
}

function gui.pressed(x, y)
    for i = 1, #gui.buttons do
        if inBox(x,y,
                     gui.buttons[i].x-buttonSizeX/2,
                     gui.buttons[i].y-buttonSizeY/2,
                     buttonSizeX, buttonSizeY) then
            gui.buttons[i].onPress()
        end
    end

end

function gui.draw()
    local draw = love.graphics.draw
    for i = 1, #gui.buttons do
        love.graphics.setColor(
            (gui.buttons[i].scale^2)*255,
            (gui.buttons[i].scale^2)*255,
            (gui.buttons[i].scale^2)*255,
            255
        )
        draw(gui.buttons[i].img,screen.width * gui.buttons[i].x-(gui.buttons[i].scale * screen.width * buttonSizeX/2), screen.height * gui.buttons[i].y-(gui.buttons[i].scale * screen.height * buttonSizeY/2), 0, screen.width * buttonSizeX * gui.buttons[i].scale/gui.buttons[i].xp, screen.height * buttonSizeY * gui.buttons[i].scale/gui.buttons[i].yp)
    end
end

return gui